﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TMC_case_team4.Data;
using TMC_case_team4.Pages.MainPages;

namespace TMC_case_team4.Pages.PagesOFAcc
{
    /// <summary>
    /// Логика взаимодействия для PageLogin.xaml
    /// </summary>
    public partial class PageLogin : Page
    {
        public static User user;
        public PageLogin()
        {
            InitializeComponent();
        }

        private void btn_register_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageReg());
        }

        private void btn_come_in_Click(object sender, RoutedEventArgs e)
        {
            if (tb_login.Text.Length < 1 || tb_login.Text == "Введите логин")
            {
                MessageBox.Show("Не введен логин", "Ошибка входа", MessageBoxButton.OK, MessageBoxImage.Warning);
                tb_login.Focus();
                return;
            }
            if (pb_password.Password.Length < 1)
            {
                MessageBox.Show("Не введен пароль", "Ошибка входа", MessageBoxButton.OK, MessageBoxImage.Warning);
                pb_password.Focus();
                return;
            }
            if (OdbConnectHelper.entObj.User.Count(x => x.login == tb_login.Text && x.password == pb_password.Password) == 1)
            {
                user = OdbConnectHelper.entObj.User.Where(x => x.login == tb_login.Text && x.password == pb_password.Password).FirstOrDefault();
               // MessageBox.Show($"Здравствуйте {user.name}!",
               //"Уведомление",
               //MessageBoxButton.OK,
               //MessageBoxImage.Information);
               FrameApp.frmObj.Navigate(new PageMainMenu());
            }
            else
            {

                MessageBox.Show("Неверный логин или пароль", "Ошибка входа", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        private void LimitTextWithouZap_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            TextBox tbne = sender as TextBox;
            if ((!Char.IsDigit(e.Text, 0)) && (e.Text != ","))
            {
                { e.Handled = true; }
            }
            else
                if ((e.Text == ",") && ((tbne.Text.IndexOf(",") != -1) || (tbne.Text == "")))
            { e.Handled = true; }
        }
        private void LimitCifri_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (Char.IsDigit(e.Text, 0)) { e.Handled = true; }
        }
        private void LimitText_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Char.IsDigit(e.Text, 0)) { e.Handled = true; }
        }
        private void LimitOfSpace_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                e.Handled = true;
            }
        }
    }
}
