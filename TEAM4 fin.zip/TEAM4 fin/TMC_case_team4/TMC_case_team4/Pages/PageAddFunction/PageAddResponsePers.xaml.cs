﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TMC_case_team4.Data;

namespace TMC_case_team4.Pages.PageAddFunction
{
    /// <summary>
    /// Логика взаимодействия для PageAddResponsePers.xaml
    /// </summary>
    public partial class PageAddResponsePers : Page
    {
        public PageAddResponsePers()
        {
            InitializeComponent();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void btn_add_Click(object sender, RoutedEventArgs e)
        {
            if (tb_patronymic.Text == "")
            {
                tb_patronymic.Text = "-";
            }
            try
            {
                Responsible_persons responsible_Persons = new Responsible_persons()
                {
                    surname = tb_surname.Text,
                    name = tb_name.Text,
                    patronymic = tb_patronymic.Text
                };

                OdbConnectHelper.entObj.Responsible_persons.Add(responsible_Persons);
                OdbConnectHelper.entObj.SaveChanges();
                MessageBox.Show("Сотрудник успешно добавлен",
                                  "Уведомление",
                                  MessageBoxButton.OK,
                                  MessageBoxImage.Information);
                FrameApp.frmObj.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(),
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
            }
        }

        private void LimitCifri_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (Char.IsDigit(e.Text, 0)) { e.Handled = true; }
        }

    }
}
