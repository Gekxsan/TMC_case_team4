﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TMC_case_team4.Data;

namespace TMC_case_team4.Pages.PageAddFunction
{
    /// <summary>
    /// Логика взаимодействия для PageAddProductCard.xaml
    /// </summary>
    public partial class PageAddProductCard : Page
    {
        public PageAddProductCard()
        {
            InitializeComponent();

            cb_person.DisplayMemberPath = "surname";
            cb_person.SelectedValuePath = "ID_responsible_persons";
            cb_person.ItemsSource = OdbConnectHelper.entObj.Responsible_persons.ToList();

            cb_act.DisplayMemberPath = "number_act";
            cb_act.SelectedValuePath = "number_act";
            cb_act.ItemsSource = OdbConnectHelper.entObj.Act.ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void btn_add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Product_map product_map = new Product_map()
                {
                    inventory_number = int.Parse(tb_i_number.Text),
                    serial_number = tb_s_number.Text,
                    Act = cb_act.SelectedItem as Act,
                    Responsible_persons = cb_person.SelectedItem as Responsible_persons,
                    ID_status = 1
                };

                OdbConnectHelper.entObj.Product_map.Add(product_map);
                OdbConnectHelper.entObj.SaveChanges();
                MessageBox.Show("Карточка товара успешно добавлена",
                                  "Уведомление",
                                  MessageBoxButton.OK,
                                  MessageBoxImage.Information);
                FrameApp.frmObj.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(),
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
            }
        }
    }
}
