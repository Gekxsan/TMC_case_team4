﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TMC_case_team4.Data;

namespace TMC_case_team4.Pages.MainPages
{
    /// <summary>
    /// Логика взаимодействия для PageGuide.xaml
    /// </summary>
    public partial class PageGuide : Page
    {
        string flag = "";
        public PageGuide()
        {
            InitializeComponent();
            btn_delete.Visibility = Visibility.Hidden;
            btn_edit.Visibility = Visibility.Hidden;
            btn_add.Visibility = Visibility.Hidden;
            tb_add.Visibility = Visibility.Hidden;
            lb_add.Visibility = Visibility.Hidden;
        }


        private void btn_catergory_Click(object sender, RoutedEventArgs e)
        {
            tb_add.Text = "";
            GridList.ItemsSource = OdbConnectHelper.entObj.Category.ToList();
            flag = "category";
            if (btn_add.Visibility == Visibility.Hidden)
            {
                btn_add.Visibility = Visibility.Visible;
                btn_edit.Visibility = Visibility.Visible;
                btn_delete.Visibility = Visibility.Visible;
                tb_add.Visibility = Visibility.Visible;
                lb_add.Visibility = Visibility.Visible;
            }
        }

        private void btn_company_Click(object sender, RoutedEventArgs e)
        {
            tb_add.Text = "";
            GridList.ItemsSource = OdbConnectHelper.entObj.Company.ToList();
            flag = "company";
            if (btn_add.Visibility == Visibility.Hidden)
            {
                btn_add.Visibility = Visibility.Visible;
                btn_edit.Visibility = Visibility.Visible;
                btn_delete.Visibility = Visibility.Visible;
                tb_add.Visibility = Visibility.Visible;
                lb_add.Visibility = Visibility.Visible;
            }
        }

        private void btn_status_Click(object sender, RoutedEventArgs e)
        {
            tb_add.Text = "";
            GridList.ItemsSource = OdbConnectHelper.entObj.Status.ToList();
            flag = "status";
            if (btn_add.Visibility == Visibility.Hidden)
            {
                btn_add.Visibility = Visibility.Visible;
                btn_edit.Visibility = Visibility.Visible;
                btn_delete.Visibility = Visibility.Visible;
                tb_add.Visibility = Visibility.Visible;
                lb_add.Visibility = Visibility.Visible;
            }
        }

        private void btn_division_Click(object sender, RoutedEventArgs e)
        {
            tb_add.Text = "";
            GridList.ItemsSource = OdbConnectHelper.entObj.Division.ToList();
            flag = "division";
            if (btn_add.Visibility == Visibility.Hidden)
            {
                btn_add.Visibility = Visibility.Visible;
                btn_edit.Visibility = Visibility.Visible;
                btn_delete.Visibility = Visibility.Visible;
                tb_add.Visibility = Visibility.Visible;
                lb_add.Visibility = Visibility.Visible;
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            btn_add.Visibility = Visibility.Hidden;
            btn_edit.Visibility = Visibility.Hidden;
            btn_delete.Visibility = Visibility.Hidden;
            tb_add.Visibility = Visibility.Hidden;
            lb_add.Visibility = Visibility.Hidden;
            FrameApp.frmObj.GoBack();
        }

        private void btn_delete_Click(object sender, RoutedEventArgs e)
        {
            switch (flag)
            {
                case "category":
                    try
                    {
                        if (GridList.SelectedItems.Count > 0)
                        {
                            MessageBoxResult result = MessageBox.Show($"Вы действительно хотите удалить {GridList.SelectedItems.Count} запись(-и)?",
                                                                  "Предупреждение",
                                                                  MessageBoxButton.YesNo,
                                                                  MessageBoxImage.Warning);
                            if (result == MessageBoxResult.Yes)
                            {
                                for (int i = 0; i < GridList.SelectedItems.Count;)
                                {
                                    Category catObj = GridList.SelectedItems[i] as Category;
                                    if (catObj != null)
                                    {

                                        OdbConnectHelper.entObj.Category.Remove(catObj);
                                        OdbConnectHelper.entObj.SaveChanges();
                                        GridList.ItemsSource = OdbConnectHelper.entObj.Category.ToList();
                                    }
                                    else
                                    {
                                        return;
                                    }
                                }
                                GridList.SelectedIndex = 0;
                                MessageBox.Show("Удаление успешно завершено",
                                        "Уведомление",
                                        MessageBoxButton.OK,
                                        MessageBoxImage.Information);
                            }
                            if (result == MessageBoxResult.No)
                                return;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString(),
                                        "Ошибка",
                                        MessageBoxButton.OK,
                                        MessageBoxImage.Error);
                    }
                    break;
                case "company":
                    try
                    {
                        if (GridList.SelectedItems.Count > 0)
                        {
                            MessageBoxResult result = MessageBox.Show($"Вы действительно хотите удалить {GridList.SelectedItems.Count} запись(-и)?",
                                                                  "Предупреждение",
                                                                  MessageBoxButton.YesNo,
                                                                  MessageBoxImage.Warning);
                            if (result == MessageBoxResult.Yes)
                            {
                                for (int i = 0; i < GridList.SelectedItems.Count;)
                                {
                                    Company comObj = GridList.SelectedItems[i] as Company;
                                    if (comObj != null)
                                    {

                                        OdbConnectHelper.entObj.Company.Remove(comObj);
                                        OdbConnectHelper.entObj.SaveChanges();
                                        GridList.ItemsSource = OdbConnectHelper.entObj.Company.ToList();
                                    }
                                    else
                                    {
                                        return;
                                    }
                                }
                                GridList.SelectedIndex = 0;
                                MessageBox.Show("Удаление успешно завершено",
                                        "Уведомление",
                                        MessageBoxButton.OK,
                                        MessageBoxImage.Information);
                            }
                            if (result == MessageBoxResult.No)
                                return;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString(),
                                        "Ошибка",
                                        MessageBoxButton.OK,
                                        MessageBoxImage.Error);
                    }
                    break;
                case "status":
                    try
                    {
                        if (GridList.SelectedItems.Count > 0)
                        {
                            MessageBoxResult result = MessageBox.Show($"Вы действительно хотите удалить {GridList.SelectedItems.Count} запись(-и)?",
                                                                  "Предупреждение",
                                                                  MessageBoxButton.YesNo,
                                                                  MessageBoxImage.Warning);
                            if (result == MessageBoxResult.Yes)
                            {
                                for (int i = 0; i < GridList.SelectedItems.Count;)
                                {
                                    Status statObj = GridList.SelectedItems[i] as Status;
                                    if (statObj != null)
                                    {

                                        OdbConnectHelper.entObj.Status.Remove(statObj);
                                        OdbConnectHelper.entObj.SaveChanges();
                                        GridList.ItemsSource = OdbConnectHelper.entObj.Status.ToList();
                                    }
                                    else
                                    {
                                        return;
                                    }
                                }
                                GridList.SelectedIndex = 0;
                                MessageBox.Show("Удаление успешно завершено",
                                        "Уведомление",
                                        MessageBoxButton.OK,
                                        MessageBoxImage.Information);
                            }
                            if (result == MessageBoxResult.No)
                                return;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString(),
                                        "Ошибка",
                                        MessageBoxButton.OK,
                                        MessageBoxImage.Error);
                    }
                    break;
                case "division":
                    try
                    {
                        if (GridList.SelectedItems.Count > 0)
                        {
                            MessageBoxResult result = MessageBox.Show($"Вы действительно хотите удалить {GridList.SelectedItems.Count} запись(-и)?",
                                                                  "Предупреждение",
                                                                  MessageBoxButton.YesNo,
                                                                  MessageBoxImage.Warning);
                            if (result == MessageBoxResult.Yes)
                            {
                                for (int i = 0; i < GridList.SelectedItems.Count;)
                                {
                                    Division divObj = GridList.SelectedItems[i] as Division;
                                    if (divObj
                                        != null)
                                    {

                                        OdbConnectHelper.entObj.Division.Remove(divObj);
                                        OdbConnectHelper.entObj.SaveChanges();
                                        GridList.ItemsSource = OdbConnectHelper.entObj.Division.ToList();
                                    }
                                    else
                                    {
                                        return;
                                    }
                                }
                                GridList.SelectedIndex = 0;
                                MessageBox.Show("Удаление успешно завершено",
                                        "Уведомление",
                                        MessageBoxButton.OK,
                                        MessageBoxImage.Information);
                            }
                            if (result == MessageBoxResult.No)
                                return;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString(),
                                        "Ошибка",
                                        MessageBoxButton.OK,
                                        MessageBoxImage.Error);
                    }
                    break;

            }
        }

        private void btn_edit_Click(object sender, RoutedEventArgs e)
        {
            switch (flag)
            {
                case "category":
                    OdbConnectHelper.entObj.SaveChanges();
                    break;
                case "company":
                    OdbConnectHelper.entObj.SaveChanges();
                    break;
                case "status":
                    OdbConnectHelper.entObj.SaveChanges();
                    break;
                case "division":
                    OdbConnectHelper.entObj.SaveChanges();
                    break;
            }
        }

        private void btn_add_Click(object sender, RoutedEventArgs e)
        {
            switch (flag)
            {
                case "category":
                    Category catObj = new Category
                    {
                        title = tb_add.Text
                    };
                    OdbConnectHelper.entObj.Category.Add(catObj);
                    OdbConnectHelper.entObj.SaveChanges();
                    MessageBox.Show("Категория успешно добавлена",
                                      "Уведомление",
                                      MessageBoxButton.OK,
                                      MessageBoxImage.Information);
                    tb_add.Clear();
                    GridList.ItemsSource = OdbConnectHelper.entObj.Category.ToList();
                    break;
                case "company":
                    Company comObj = new Company
                    {
                        title = tb_add.Text
                    };
                    OdbConnectHelper.entObj.Company.Add(comObj);
                    OdbConnectHelper.entObj.SaveChanges();
                    MessageBox.Show("Компания успешно добавлена",
                                      "Уведомление",
                                      MessageBoxButton.OK,
                                      MessageBoxImage.Information);
                    tb_add.Clear();
                    GridList.ItemsSource = OdbConnectHelper.entObj.Company.ToList();
                    break;
                case "status":
                    Status satObj = new Status
                    {
                        title = tb_add.Text
                    };
                    OdbConnectHelper.entObj.Status.Add(satObj);
                    OdbConnectHelper.entObj.SaveChanges();
                    MessageBox.Show("Статус успешно добавлена",
                                      "Уведомление",
                                      MessageBoxButton.OK,
                                      MessageBoxImage.Information);
                    tb_add.Clear();
                    GridList.ItemsSource = OdbConnectHelper.entObj.Status.ToList();
                    break;
                case "division":
                    Division divObj = new Division
                    {
                        title = tb_add.Text
                    };
                    OdbConnectHelper.entObj.Division.Add(divObj);
                    OdbConnectHelper.entObj.SaveChanges();
                    MessageBox.Show("Отдел успешно добавлена",
                                      "Уведомление",
                                      MessageBoxButton.OK,
                                      MessageBoxImage.Information);
                    tb_add.Clear();
                    GridList.ItemsSource = OdbConnectHelper.entObj.Division.ToList();
                    break;
            }
        }

        private void CheckText_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            switch (flag)
            {
                case "category":
                    if (Char.IsDigit(e.Text, 0)) { e.Handled = true; }
                    tb_add.MaxLength = 99;
                    break;
                case "company":
                    if (Char.IsDigit(e.Text, 0)) { e.Handled = true; }
                    tb_add.MaxLength = 149;
                    break;
                case "status":
                    if (Char.IsDigit(e.Text, 0)) { e.Handled = true; }
                    tb_add.MaxLength = 99;
                    break;
                case "division":
                    break;
            }
        }
    }
}
