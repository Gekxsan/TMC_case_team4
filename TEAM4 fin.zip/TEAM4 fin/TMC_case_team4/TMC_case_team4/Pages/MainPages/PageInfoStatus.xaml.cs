﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TMC_case_team4.Data;

namespace TMC_case_team4.Pages.MainPages
{
    /// <summary>
    /// Логика взаимодействия для PageInfoStatus.xaml
    /// </summary>
    public partial class PageInfoStatus : Page
    {
        public PageInfoStatus(Act actObj)
        {
            InitializeComponent();

            GridList.ItemsSource = OdbConnectHelper.entObj.Story.Where(x => x.number_act == actObj.number_act).ToList();    
        }

        private void btn_add_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_delete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_edit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }
    }
}
