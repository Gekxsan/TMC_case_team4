﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TMC_case_team4.Data;
using TMC_case_team4.Pages.PageAddFunction;

namespace TMC_case_team4.Pages.MainPages
{
    /// <summary>
    /// Логика взаимодействия для PageProduct.xaml
    /// </summary>
    public partial class PageProduct : Page
    {
        public PageProduct()
        {
            InitializeComponent();
            GridList.ItemsSource = OdbConnectHelper.entObj.Product.ToList();
            List<string> list = new List<string> { };
            for (int i = 0; i < GridList.Columns.Count; i++)
            {
                list.Add(GridList.Columns[i].Header.ToString());
            }
            cb_sort.ItemsSource = list;
        }
        private void btn_add_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageAddProduct());
        }

        private void btn_delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (GridList.SelectedItems.Count > 0)
                {
                    MessageBoxResult result = MessageBox.Show($"Вы действительно хотите удалить {GridList.SelectedItems.Count} запись(-и)?",
                                                          "Предупреждение",
                                                          MessageBoxButton.YesNo,
                                                          MessageBoxImage.Warning);
                    if (result == MessageBoxResult.Yes)
                    {
                        for (int i = 0; i < GridList.SelectedItems.Count;)
                        {
                            Product product = GridList.SelectedItems[i] as Product;
                            if (product != null)
                            {

                                OdbConnectHelper.entObj.Product.Remove(product);
                                OdbConnectHelper.entObj.SaveChanges();
                                GridList.ItemsSource = OdbConnectHelper.entObj.Product.ToList();
                            }
                            else
                            {
                                return;
                            }
                        }
                        GridList.SelectedIndex = 0;
                        MessageBox.Show("Удаление успешно завершено",
                                "Уведомление",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
                    }
                    if (result == MessageBoxResult.No)
                        return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(),
                                "Ошибка",
                                MessageBoxButton.OK,
                                MessageBoxImage.Error);
            }
        }

        private void btn_edit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OdbConnectHelper.entObj.SaveChanges();
                MessageBox.Show("Изменения применены",
                                "Уведомление",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(),
                                "Ошибка",
                                MessageBoxButton.OK,
                                MessageBoxImage.Error);
            }
        }

        private void cb_sort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            cb_item.IsEnabled = true;
            switch (cb_sort.SelectedItem.ToString())
            {
                case "Название (тип) продукта":
                    cb_item.DisplayMemberPath = "title";
                    cb_item.SelectedValuePath = "title";
                    cb_item.ItemsSource = from x in OdbConnectHelper.entObj.Product.Local group x by x.title into g select new { title = g.Key };
                    break;
                case "Категория продукта":
                    cb_item.DisplayMemberPath = "title";
                    cb_item.SelectedValuePath = "ID_category";
                    cb_item.ItemsSource = OdbConnectHelper.entObj.Category.ToList();
                    break;
                default:
                    break;
            }
        }

        private void cb_item_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cb_item.SelectedValue == null)
            {
                return;
            }
            string select = cb_item.SelectedValue.ToString();
            switch (cb_sort.SelectedItem.ToString())
            {
                case "Название (тип) продукта":
                    GridList.ItemsSource = OdbConnectHelper.entObj.Product.Where(x => x.title == select).ToList();
                    break;
                case "Категория продукта":
                    GridList.ItemsSource = OdbConnectHelper.entObj.Product.Where(x => x.ID_category.ToString() == select).ToList();
                    break;
                default:
                    break;
            }
        }

        private void btn_reset_Click(object sender, RoutedEventArgs e)
        {
            cb_item.Text = "";
            GridList.ItemsSource = OdbConnectHelper.entObj.Product.ToList();
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            GridList.ItemsSource = OdbConnectHelper.entObj.Product.ToList();
        }
    }
}
