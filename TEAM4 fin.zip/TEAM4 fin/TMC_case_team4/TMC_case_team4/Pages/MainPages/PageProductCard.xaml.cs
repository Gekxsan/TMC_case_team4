﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TMC_case_team4.Data;
using TMC_case_team4.Pages.PageAddFunction;

namespace TMC_case_team4.Pages.MainPages
{
    /// <summary>
    /// Логика взаимодействия для PageProductCard.xaml
    /// </summary>
    public partial class PageProductCard : Page
    {
        public PageProductCard()
        {
            InitializeComponent();
            GridList.SelectedValuePath = "inventory_number";
            GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.ToList();
            List<string> list = new List<string> { };
            for (int i = 0; i < GridList.Columns.Count - 1; i++)
            {
                list.Add(GridList.Columns[i].Header.ToString());
            }
            cb_sort.ItemsSource = list;
            cb_search.ItemsSource = new List<string> { GridList.Columns[0].Header.ToString(),
            GridList.Columns[0].Header.ToString() };
        }
        private void btn_add_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageAddProductCard());
        }

        private void btn_delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (GridList.SelectedItems.Count > 0)
                {
                    MessageBoxResult result = MessageBox.Show($"Вы действительно хотите удалить {GridList.SelectedItems.Count} запись(-и)?",
                                                          "Предупреждение",
                                                          MessageBoxButton.YesNo,
                                                          MessageBoxImage.Warning);
                    if (result == MessageBoxResult.Yes)
                    {
                        for (int i = 0; i < GridList.SelectedItems.Count;)
                        {
                            Product_map ProductMap = GridList.SelectedItems[i] as Product_map;
                            if (ProductMap != null)
                            {

                                OdbConnectHelper.entObj.Product_map.Remove(ProductMap);
                                OdbConnectHelper.entObj.SaveChanges();
                                GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.ToList();
                            }
                            else
                            {
                                return;
                            }
                        }
                        GridList.SelectedIndex = 0;
                        MessageBox.Show("Удаление успешно завершено",
                                "Уведомление",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
                    }
                    if (result == MessageBoxResult.No)
                        return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(),
                                "Ошибка",
                                MessageBoxButton.OK,
                                MessageBoxImage.Error);
            }
        }

        private void btn_edit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OdbConnectHelper.entObj.SaveChanges();
                MessageBox.Show("Изменения применены",
                                "Уведомление",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(),
                                "Ошибка",
                                MessageBoxButton.OK,
                                MessageBoxImage.Error);
            }
        }

        private void cb_sort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            cb_item.IsEnabled = true;
            switch (cb_sort.SelectedItem.ToString())
            {
                case "Инвентарный номер":
                    cb_item.DisplayMemberPath = "inventory_number";
                    cb_item.SelectedValuePath = "inventory_number";
                    cb_item.ItemsSource = from x in OdbConnectHelper.entObj.Product_map.Local group x by x.inventory_number into g select new { inventory_number = g.Key };
                    break;
                case "Серийный номер":
                    cb_item.DisplayMemberPath = "serial_number";
                    cb_item.SelectedValuePath = "serial_number";
                    cb_item.ItemsSource = from x in OdbConnectHelper.entObj.Product_map.Local group x by x.serial_number into g select new { serial_number = g.Key };
                    break;
                case "Номер акта":
                    cb_item.DisplayMemberPath = "number_act";
                    cb_item.SelectedValuePath = "number_act";
                    cb_item.ItemsSource = OdbConnectHelper.entObj.Act.ToList();
                    break;
                case "Ответственное лицо":
                    cb_item.DisplayMemberPath = "surname";
                    cb_item.SelectedValuePath = "ID_responsible_persons";
                    cb_item.ItemsSource = OdbConnectHelper.entObj.Responsible_persons.ToList();
                    break;
                default:
                    break;
            }
        }

        private void cb_item_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cb_item.SelectedValue == null)
            {
                return;
            }
            string select = cb_item.SelectedValue.ToString();
            switch (cb_sort.SelectedItem.ToString())
            {
                case "Инвентарный номер":
                    GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.inventory_number.ToString() == select).ToList();
                    break;
                case "Серийный номер":
                    GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.serial_number == select).ToList();
                    break;
                case "Номер акта":
                    GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.number_act.ToString() == select).ToList();
                    break;
                case "Ответственное лицо":
                    GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.ID_responsible_persons.ToString() == select).ToList();
                    break;
                default:
                    break;
            }
        }

        private void rb_search_Checked(object sender, RoutedEventArgs e)
        {
            cb_sort.IsEnabled = false;
            cb_item.IsEnabled = false;
            cb_search.IsEnabled = true;
            tb_search.IsEnabled = true;
            GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.ToList();
        }

        private void rb_search_Unchecked(object sender, RoutedEventArgs e)
        {
            cb_sort.IsEnabled = true;
            cb_item.IsEnabled = false;
            cb_search.IsEnabled = false;
            tb_search.IsEnabled = false;
            GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.ToList();
        }

        private void tb_search_TextChanged(object sender, TextChangedEventArgs e)
        {
            switch (cb_search.SelectedItem.ToString())
            {
                case "Инвентарный номер":
                    GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.inventory_number.ToString().StartsWith(tb_search.Text)).ToList();
                    break;
                case "Серийный номер":
                    GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.serial_number.StartsWith(tb_search.Text)).ToList();
                    break;
                default:
                    break;
            }
        }

        private void btn_reset_Click(object sender, RoutedEventArgs e)
        {
            tb_search.Text = "";
            GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.ToList();
        }

        private void cb_search_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            tb_search.Text = "";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.ToList();
        }       
    }
}
