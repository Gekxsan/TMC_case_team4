﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TMC_case_team4.Data;

namespace TMC_case_team4.Pages.MainPages
{
    /// <summary>
    /// Логика взаимодействия для PageStoryAll.xaml
    /// </summary>
    public partial class PageStoryAll : Page
    {
        public PageStoryAll()
        {
            InitializeComponent();

            GridList.ItemsSource = OdbConnectHelper.entObj.Story.ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void btn_reset_Click(object sender, RoutedEventArgs e)
        {
            tb_item.Text = "";
            GridList.ItemsSource = OdbConnectHelper.entObj.Story.ToList();
        }

        private void tb_item_TextChanged(object sender, TextChangedEventArgs e)
        {
            var invNumObj = OdbConnectHelper.entObj.Story.Where(x => x.inventory_number.ToString().StartsWith(tb_item.Text)).ToList();
            GridList.ItemsSource = invNumObj;
        }
    }
}
