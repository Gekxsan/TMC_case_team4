﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TMC_case_team4.Data;
using TMC_case_team4.Windows;

namespace TMC_case_team4.Pages.MainPages
{
    /// <summary>
    /// Логика взаимодействия для PageMainMenu.xaml
    /// </summary>
    public partial class PageMainMenu : Page
    {
        public PageMainMenu()
        {
            InitializeComponent();
        }

        private void btn_responsible_persons_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageResponsePers());
        }

        private void btn_products_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageProduct());
        }

        private void btn_actshow_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageNaznachenie());
        }

        private void btn_duide_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageGuide());
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void btn_act_Click(object sender, RoutedEventArgs e)
        {
            WindowCardProduct wk = new WindowCardProduct();
            wk.Show();
        }

        private void btn_Story_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageStoryAll());
        }

        private void btn_Archiev_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageArchiev());
        }
    }
}
