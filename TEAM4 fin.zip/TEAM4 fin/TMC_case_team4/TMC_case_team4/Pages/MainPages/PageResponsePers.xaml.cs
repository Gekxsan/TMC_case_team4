﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TMC_case_team4.Data;
using TMC_case_team4.Pages.PageAddFunction;

namespace TMC_case_team4.Pages.MainPages
{
    /// <summary>
    /// Логика взаимодействия для PageResponsePers.xaml
    /// </summary>
    public partial class PageResponsePers : Page
    {
        public PageResponsePers()
        {
            InitializeComponent();
            GridList.ItemsSource = OdbConnectHelper.entObj.Responsible_persons.ToList();
            List<string> list = new List<string> { };
            for (int i = 0; i < GridList.Columns.Count; i++)
            {
                list.Add(GridList.Columns[i].Header.ToString());
            }
            cb_search.ItemsSource = list;
        }
        private void btn_add_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageAddResponsePers());
        }

        private void btn_delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (GridList.SelectedItems.Count > 0)
                {
                    MessageBoxResult result = MessageBox.Show($"Вы действительно хотите удалить {GridList.SelectedItems.Count} запись(-и)?",
                                                          "Предупреждение",
                                                          MessageBoxButton.YesNo,
                                                          MessageBoxImage.Warning);
                    if (result == MessageBoxResult.Yes)
                    {
                        for (int i = 0; i < GridList.SelectedItems.Count;)
                        {
                            Responsible_persons responsible_Persons = GridList.SelectedItems[i] as Responsible_persons;
                            if (responsible_Persons != null)
                            {

                                OdbConnectHelper.entObj.Responsible_persons.Remove(responsible_Persons);
                                OdbConnectHelper.entObj.SaveChanges();
                                GridList.ItemsSource = OdbConnectHelper.entObj.Responsible_persons.ToList();
                            }
                            else
                            {
                                return;
                            }
                        }
                        GridList.SelectedIndex = 0;
                        MessageBox.Show("Удаление успешно завершено",
                                "Уведомление",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
                    }
                    if (result == MessageBoxResult.No)
                        return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(),
                                "Ошибка",
                                MessageBoxButton.OK,
                                MessageBoxImage.Error);
            }
        }

        private void btn_edit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OdbConnectHelper.entObj.SaveChanges();
                MessageBox.Show("Изменения применены",
                                "Уведомление",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(),
                                "Ошибка",
                                MessageBoxButton.OK,
                                MessageBoxImage.Error);
            }
        }

        private void tb_search_TextChanged(object sender, TextChangedEventArgs e)
        {
            switch (cb_search.SelectedItem.ToString())
            {
                case "Фамилия":
                    GridList.ItemsSource = OdbConnectHelper.entObj.Responsible_persons.Where(x => x.surname.StartsWith(tb_search.Text)).ToList();
                    break;
                case "Имя":
                    GridList.ItemsSource = OdbConnectHelper.entObj.Responsible_persons.Where(x => x.name.StartsWith(tb_search.Text)).ToList();
                    break;
                case "Отчество":
                    GridList.ItemsSource = OdbConnectHelper.entObj.Responsible_persons.Where(x => x.patronymic.StartsWith(tb_search.Text)).ToList();
                    break;
                default:
                    break;
            }
        }

        private void cb_search_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            tb_search.Text = "";
            tb_search.IsEnabled = true;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            GridList.ItemsSource = OdbConnectHelper.entObj.Responsible_persons.ToList();
        }
    }
}
